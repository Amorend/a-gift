package android.support.design.internal;

import android.view.ViewGroup;

class BottomNavigationAnimationHelperBase
{
  void beginDelayedTransition(ViewGroup paramViewGroup) {}
}


/* Location:              C:\Users\12724\Desktop\classes-dex2jar.jar!\android\support\design\internal\BottomNavigationAnimationHelperBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
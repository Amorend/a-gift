package android.support.design.internal;

import android.support.annotation.RestrictTo;

@RestrictTo({android.support.annotation.RestrictTo.Scope.LIBRARY_GROUP})
abstract interface package-info {}


/* Location:              C:\Users\12724\Desktop\classes-dex2jar.jar!\android\support\design\internal\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
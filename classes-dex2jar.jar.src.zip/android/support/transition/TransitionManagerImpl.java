package android.support.transition;

abstract class TransitionManagerImpl
{
  public abstract void setTransition(SceneImpl paramSceneImpl1, SceneImpl paramSceneImpl2, TransitionImpl paramTransitionImpl);
  
  public abstract void setTransition(SceneImpl paramSceneImpl, TransitionImpl paramTransitionImpl);
  
  public abstract void transitionTo(SceneImpl paramSceneImpl);
}


/* Location:              C:\Users\12724\Desktop\classes-dex2jar.jar!\android\support\transition\TransitionManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
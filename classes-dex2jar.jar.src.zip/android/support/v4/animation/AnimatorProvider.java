package android.support.v4.animation;

import android.view.View;

abstract interface AnimatorProvider
{
  public abstract void clearInterpolator(View paramView);
  
  public abstract ValueAnimatorCompat emptyValueAnimator();
}


/* Location:              C:\Users\12724\Desktop\classes-dex2jar.jar!\android\support\v4\animation\AnimatorProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.support.v4.app;

import android.annotation.TargetApi;
import android.support.annotation.RequiresApi;

@TargetApi(14)
@RequiresApi(14)
class NotificationManagerCompatIceCreamSandwich
{
  static final int SIDE_CHANNEL_BIND_FLAGS = 33;
}


/* Location:              C:\Users\12724\Desktop\classes-dex2jar.jar!\android\support\v4\app\NotificationManagerCompatIceCreamSandwich.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package android.app;

import android.content.Context;
import com.androlua.LuaDialog;

public class AlertDialogBuilder
  extends LuaDialog
{
  public AlertDialogBuilder(Context paramContext)
  {
    super(paramContext);
  }
  
  public AlertDialogBuilder(Context paramContext, int paramInt)
  {
    super(paramContext, paramInt);
  }
}


/* Location:              C:\Users\12724\Desktop\classes-dex2jar.jar!\android\app\AlertDialogBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */